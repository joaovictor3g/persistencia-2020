package DAO;

import java.net.FileNameMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.PropertyPermission;

import Model.Funcionario;
import database.ConnectionFactory;

public class FuncionarioDAO {
    private Connection connection;

    public FuncionarioDAO() throws SQLException {
        this.connection = ConnectionFactory.getConnection();
    }

    public boolean verificaMatriculaExiste(String matricula) {
        String sql = "select matricula from Funcionarios";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()) {
                if(matricula.equals(resultSet.getString("matricula"))) {
                    System.out.println("MATRÍCULA JÁ EXISTE");
                    resultSet.close();
                    preparedStatement.close();
                    return true;
                }
            }
            resultSet.close();
            preparedStatement.close();
            return false;

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }

        return false;
    }

    public boolean verificaCpfExiste(String matricula) {
        String sql = "select cpf from Funcionarios";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()) {
                if(matricula.equals(resultSet.getString("cpf"))) {
                    System.out.println("CPF JÁ EXISTE");
                    resultSet.close();
                    preparedStatement.close();
                    return true;
                }
            }
            resultSet.close();
            preparedStatement.close();
            return false;

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }

        return false;
    }

    public void adiciona(Funcionario funcionario) {
        String sql = "insert into Funcionarios" +
                "(nome, cpf, email, telefone, matricula)" +
                "values (?, ?, ?, ?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, funcionario.getNome());
            preparedStatement.setString(2, funcionario.getCpf());
            preparedStatement.setString(3, funcionario.getEmail());
            preparedStatement.setString(4, funcionario.getTelefone());
            preparedStatement.setString(5, funcionario.getMatricula());

            preparedStatement.execute();
            preparedStatement.close();

            System.out.println("Funcionário adicionado");
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }

    public void deleta(int id) {
        String sql = "delete from Funcionarios where id_funcionario = (?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            preparedStatement.close();

            System.out.println("Funcionário deletado");
        } catch (SQLException sqlEx) {
            System.out.println("ID inexistente");
            sqlEx.printStackTrace();
        }
    }

    public void alterar(Funcionario funcionario, int id) {
        String sql =
                "update Funcionarios " +
                        "set nome=(?), email=(?), telefone=(?), cpf=(?), matricula=(?) " +
                        "where id_funcionario = (?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, funcionario.getNome());
            preparedStatement.setString(2, funcionario.getEmail());
            preparedStatement.setString(3, funcionario.getTelefone());
            preparedStatement.setString(4, funcionario.getCpf());
            preparedStatement.setString(5, funcionario.getMatricula());
            preparedStatement.setInt(6, id);

            preparedStatement.executeUpdate();
            preparedStatement.close();

            System.out.println("Funcionário atualizado");
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }

    public Funcionario consulta(int id) {
        String sql = "select * from Funcionarios where id_funcionario=?";
        Funcionario funcionario = new Funcionario();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()) {
                funcionario.setEmail(resultSet.getString("email"));
                funcionario.setNome(resultSet.getString("nome"));
                funcionario.setTelefone(resultSet.getString("telefone"));
                funcionario.setMatricula(resultSet.getString("matricula"));
                funcionario.setCpf(resultSet.getString("cpf"));
            }
            resultSet.close();
            preparedStatement.close();

        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
        return funcionario;
    }

    public void adicionaListaFuncionarios(List<Funcionario> funcionarios) {
        String sql = "insert into Funcionarios" +
                "(nome, cpf, email, telefone, matricula)" +
                "values (?, ?, ?, ?, ?)";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            for(Funcionario funcionario: funcionarios) {
                preparedStatement.setString(1, funcionario.getNome());
                preparedStatement.setString(2, funcionario.getCpf());
                preparedStatement.setString(3, funcionario.getEmail());
                preparedStatement.setString(4, funcionario.getTelefone());
                preparedStatement.setString(5, funcionario.getMatricula());
                preparedStatement.execute();
            }


            preparedStatement.close();
            System.out.println("Funcionários adicionados");

        } catch(SQLException sqlEx) {
            sqlEx.printStackTrace();
        }
    }

    public List<Funcionario> listaPaginada(int pagina, int tamanhoPagina) {
        String sql = "select * from Funcionarios limit ? offset ?";
        List<Funcionario> funcionarios = new ArrayList<>();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, tamanhoPagina);
            preparedStatement.setInt(2, (pagina*tamanhoPagina)-tamanhoPagina);
            ResultSet resultSet = preparedStatement.executeQuery();

            while(resultSet.next()) {
                Funcionario funcionario = new Funcionario();
                funcionario.setNome(resultSet.getString("nome"));
                funcionario.setEmail(resultSet.getString("email"));
                funcionario.setTelefone(resultSet.getString("telefone"));
                funcionario.setMatricula(resultSet.getString("matricula"));
                funcionario.setCpf(resultSet.getString("cpf"));

                funcionarios.add(funcionario);
            }
            resultSet.close();
            preparedStatement.close();

//            System.out.println("Lista Paginada");
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        }

        return funcionarios;
    }
}
