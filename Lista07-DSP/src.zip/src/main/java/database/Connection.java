package database;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class Connection {
    public static JedisPool getJedisPoolConnection() {
        JedisPool jedisPool = new JedisPool(
                    new JedisPoolConfig(), "localhost");

        System.out.println("conected");
        return jedisPool;
    }

}
