import database.Connection;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.*;

public class GetArticlesAndTags {
    static int CURRENT_ARTICLE = 1;

    static Scanner input = new Scanner(System.in);
    static JedisPool jedisPool = Connection.getJedisPoolConnection();
    static Jedis jedis = jedisPool.getResource();

    static public void insert() {
        System.out.println("Insert articles");
        Map<String, String> stringMap = new HashMap<>();
        String name, filename, posting_date, desc;

        System.out.println("Give a name for your article");
        name = input.next();
        System.out.println("Give a filename for your article");
        filename = input.next();
        System.out.println("Date");
        posting_date = input.next();
        System.out.println("Give a description for your article");
        desc = input.next();

        stringMap.put("name", name);
        stringMap.put("filename", filename);
        stringMap.put("desc", desc);
        stringMap.put("posting_date", posting_date);
        jedis.hmset("art:"+CURRENT_ARTICLE, stringMap);

        String tag = "";
        System.out.println("Now, tag your article");
        tag=input.next();

        jedis.sadd("tags:art:"+tag, String.valueOf(CURRENT_ARTICLE));

        CURRENT_ARTICLE++;
    }

    static public void showAllArticles() {
        int verifier = 1, index = 1;
        final int[] current_article = {1};

        while(verifier>0) {
            Map<String, String> getAllArticles = jedis.hgetAll("art:"+index);
            verifier = getAllArticles.size();
            if(verifier==0)
                break;
            System.out.println("Identifier: " + current_article[0]++);
            getAllArticles.entrySet().forEach(entry->{
                if(entry.getKey().equals("name") || entry.getKey().equals("desc"))
                    System.out.println(entry.getKey() + ": " + entry.getValue());
            });
            System.out.println("---------------------");
            index++;
        }
    }

    static public void showTagsFromDeterminedArticle(int index) {
        System.out.println("Tags");
        Set<String> tags = jedis.smembers("art:"+index+":tags");

        for (String tag : tags)
            System.out.println(tag);
        System.out.println("---------------------");
    }

    static public void showAllArticlesFromDeterminedTag(String tag) {
        System.out.println("Articles");
        int tagIndex = 0;
        Set<String> stringSet = jedis.smembers("tags:art:"+tag);
        int verifier = stringSet.size();
//        System.out.println(verifier);

        String[] tagArray = new String[verifier];
        int index = 0;
        for(String tagValue: stringSet) {
            System.out.println(tagValue);
            tagArray[index] = tagValue;
            index++;
        }

        while(verifier > 0) {
            Map<String, String> getAllArticles = jedis.hgetAll("art:"+tagArray[tagIndex]);

            getAllArticles.entrySet().forEach(entry->{
                System.out.println(entry.getKey() + ": " + entry.getValue());
            });
            System.out.println("---------------------");
            tagIndex++;
            verifier--;
        }
    }

    static public int menu() {
        System.out.println("Menu");
        int choice = 0;
        System.out.println("1 - Add article    2 - List articles by tag\n" +
                "3 - List tags by article      4 - List name and description of all articles\n" +
                "0 - Sair");
        choice = input.nextInt();

        return  choice;
    }

    public static void main(String[] args) {
        int principalMenu = menu();

        while(true) {
            switch (principalMenu) {
                case 1: {
                    insert();
                    principalMenu = menu();
                }
                break;
                case 2: {
                    String tag = "";

                    System.out.println("Type tag");
                    tag = input.next();

                    showAllArticlesFromDeterminedTag(tag);
                    principalMenu = menu();
                }
                break;
                case 3: {
                    int index = 0;
                    System.out.println("There are following articles");
                    showAllArticles();
                    System.out.println("Type identifier code of article");
                    index = input.nextInt();

                    showTagsFromDeterminedArticle(index);
                    principalMenu = menu();
                }
                break;

                case 4: {
                    showAllArticles();
                    principalMenu = menu();
                }
                break;
                default: {
                    jedisPool.destroy();
                    return;
                }
            }
        }
    }
}
